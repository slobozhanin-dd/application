<?php
return array(
    'form' => 'form/form',
    'credit' => 'credit/credit',
    'success' => 'credit/success',
    '' => 'form/form',
);