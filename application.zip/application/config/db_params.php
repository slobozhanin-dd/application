<?php

// Массив с параметрами подключения к базе данных
return array(
    'host' => 'localhost',
    'dbname' => 'application',
    'user' => 'root',
    'password' => 'root',
);
