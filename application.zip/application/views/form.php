<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="../css/main.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>forma</title>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script>
        $(document).ready(function() {
            $(".radio_option").change(function() {

                if ($('#fid-1').prop("checked")) {
                    $('#natural').fadeIn(300);
                    $('#legal').fadeOut(300);
                } else {
                    $('#legal').fadeIn(300);
                    $('#natural').fadeOut(300);
                }

            });
        });
    </script>

</head>
<header>
    <span>Быстро</span>Банк
</header>
<body>
    <div class="welcome">
        <p>Добро пожаловать!</p>
        <p>Кто вы?</p>
    </div>
<div class="form_toggle">
    <div class="form_toggle-item item-1">
        <input class="radio_option" id="fid-1" type="radio" name="radio" value="" checked>
        <label for="fid-1">Физическое лицо</label>
    </div>
    <div class="form_toggle-item item-2">
        <input class="radio_option" id="fid-2" type="radio" name="radio" value="">
        <label for="fid-2">Юридическое лицо</label>
    </div>
</div>
<div class="forms">
    <form id="natural" action="" method="post">
        <div class="row">
                <div class="col-25">
                    <label for="fname">Фамилия</label>
                </div>
                <div class="col-75">
                    <input type="text" id="fname" name="surname" placeholder="Ваша фамилия.." value="<?php echo $surname; ?>">
                </div>
            </div>
        <div class="row">
            <div class="col-25">
                <label for="fname">Имя</label>
            </div>
            <div class="col-75">
                <input type="text" id="fname" name="name" placeholder="Ваше имя.." value="<?php echo $name; ?>">
            </div>
        </div>
        <div class="row">
            <div class="col-25">
                <label for="fname">Отчество</label>
            </div>
            <div class="col-75">
                <input type="text" id="fname" name="patronymic" placeholder="Ваше отчество.." value="<?php echo $patronymic; ?>">
            </div>
        </div>
        <div class="row">
                <div class="col-25">
                    <label for="fname">ИНН</label>
                </div>
                <div class="col-75">
                    <input type="text" id="fname" name="inn" placeholder="Введите ИНН.." value="<?php echo $inn; ?>">
                </div>
            </div>
        <div class="row">
                <div class="col-25">
                    <label for="fname">Дата рождения</label>
                </div>
                <div class="col-75">
                    <input type="text" id="fname" name="birthdate" placeholder="В формате ГГГГ-ММ-ДД.." value="<?php echo $birthdate; ?>">
                </div>
            </div>
        <div class="row">
                <div class="col-25">
                    <label for="fname">Серия и номер паспорта</label>
                </div>
                <div class="col-75">
                    <input type="text" id="fname" name="passport" placeholder="Введите слитно.." value="<?php echo $passport; ?>">
                </div>
            </div>
        <div class="row">
                <div class="col-25">
                    <label for="fname">Дата выдачи</label>
                </div>
                <div class="col-75">
                    <input type="text" id="fname" name="dateissue" placeholder="В формате ГГГГ-ММ-ДД.." value="<?php echo $dateissue; ?>">
                </div>
            </div>
        <br>
        <div class="row">
            <input type="submit" name="nextnatural" class="button" value="Продолжить" />
        </div>
    </form>
    <form id="legal" action="" method="post">
        <div class="row">
            <div class="col-25">
                <label for="fname">Фамилия</label>
            </div>
            <div class="col-75">
                <input type="text" id="fname" name="surname" placeholder="Ваша фамилия.." value="<?php echo $surname; ?>">
            </div>
        </div>
        <div class="row">
            <div class="col-25">
                <label for="fname">Имя</label>
            </div>
            <div class="col-75">
                <input type="text" id="fname" name="name" placeholder="Ваше имя.." value="<?php echo $name; ?>">
            </div>
        </div>
        <div class="row">
            <div class="col-25">
                <label for="fname">Отчество</label>
            </div>
            <div class="col-75">
                <input type="text" id="fname" name="patronymic" placeholder="Ваше отчество.." value="<?php echo $patronymic; ?>">
            </div>
        </div>
        <div class="row">
            <div class="col-25">
                <label for="fname">ИНН</label>
            </div>
            <div class="col-75">
                <input type="text" id="fname" name="inn" placeholder="Введите ИНН.." value="<?php echo $inn; ?>">
            </div>
        </div>
        <div class="row">
            <div class="col-25">
                <label for="fname">Название компании</label>
            </div>
            <div class="col-75">
                <input type="text" id="fname" name="agencyname" placeholder="Название вашей компании.." value="<?php echo $agencyname; ?>">
            </div>
        </div>
        <div class="row">
            <div class="col-25">
                <label for="fname">Адрес компании</label>
            </div>
            <div class="col-75">
                <input type="text" id="fname" name="adress" placeholder="Введите адрес компании.." value="<?php echo $adress; ?>">
            </div>
        </div>
        <div class="row">
            <div class="col-25">
                <label for="fname">ОГРН</label>
            </div>
            <div class="col-75">
                <input type="text" id="fname" name="ogrn" placeholder="Введите ОГРН компании.." value="<?php echo $ogrn; ?>">
            </div>
        </div>
        <div class="row">
            <div class="col-25">
                <label for="fname">ИНН</label>
            </div>
            <div class="col-75">
                <input type="text" id="fname" name="agencyinn" placeholder="Введите ИНН компании.." value="<?php echo $agencyinn; ?>">
            </div>
        </div>
        <div class="row">
            <div class="col-25">
                <label for="fname">КПП</label>
            </div>
            <div class="col-75">
                <input type="text" id="fname" name="kpp" placeholder="Введите КПП компании.." value="<?php echo $kpp; ?>">
            </div>
        </div>
        <br>
        <div class="row">
            <input type="submit" name="nextlegal" class="button" value="Продолжить" />
        </div>
    </form>
    <div class="col">
        <?php if (isset($errors) && is_array($errors)): ?>
            <ul>
                <?php foreach ($errors as $error): ?>
                    <li> - <?php echo $error; ?></li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>
    </div>

</div>
</body>
</html>