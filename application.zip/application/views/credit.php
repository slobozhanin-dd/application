<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="../css/main.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>forma</title>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script>
        $(document).ready(function() {
            $(".radio_option").change(function() {

                if ($('#fid-1').prop("checked")) {
                    $('#credit').fadeIn(300);
                    $('#deposit').fadeOut(300);
                } else {
                    $('#deposit').fadeIn(300);
                    $('#credit').fadeOut(300);
                }

            });
        });
    </script>

</head>
<header>
    <span>Быстро</span>Банк
</header>
<body>
<div class="welcome">
    <p>Какую услугу вы хотите получить?</p>
</div>
<div class="form_toggle">
    <div class="form_toggle-item item-1">
        <input class="radio_option" id="fid-1" type="radio" name="radio" value="" checked>
        <label for="fid-1">Кредит</label>
    </div>
    <div class="form_toggle-item item-2">
        <input class="radio_option" id="fid-2" type="radio" name="radio" value="">
        <label for="fid-2">Депозит</label>
    </div>
</div>
<div class="forms">
    <form id="credit" action="" method="post">
        <div class="row">
            <div class="col-25">
                <label for="fname">Дата открытия</label>
            </div>
            <div class="col-75">
                <input type="text" id="fname" name="opendate" placeholder="Введите дату в формате ГГГГ-ММ-ДД.." value="<?php echo $opendate; ?>">
            </div>
        </div>
        <div class="row">
            <div class="col-25">
                <label for="fname">Срок</label>
            </div>
            <div class="col-75">
                <input type="text" id="fname" name="term" placeholder="Введите срок в месяцах.." value="<?php echo $term; ?>">
            </div>
        </div>
        <div class="row">
            <div class="col-25">
                <label for="country">График платежей</label>
            </div>
            <div class="col-75">
                <select id="country" name="diffpay">
                    <option value="1">Дифференцированный</option>
                    <option value="0">Аннуитетный</option>
                </select>
            </div>
        </div>

        <div class="row">
            <div class="col-25">
                <label for="fname">Cумма</label>
            </div>
            <div class="col-75">
                <input type="text" id="fname" name="amount" placeholder="Ввведите сумму кредита.." value="<?php echo $amount; ?>">
            </div>
        </div>
        <br>
        <div class="row">
            <input type="submit" name="credit" class="button" value="Отправить заявку" />
        </div>
    </form>
    <form id="deposit" action="" method="post">
        <div class="row">
            <div class="col-25">
                <label for="fname">Дата открытия</label>
            </div>
            <div class="col-75">
                <input type="text" id="fname" name="opendate" placeholder="Введите дату в формате ГГГГ-ММ-ДД.." value="<?php echo $opendate; ?>">
            </div>
        </div>
        <div class="row">
            <div class="col-25">
                <label for="fname">Срок</label>
            </div>
            <div class="col-75">
                <input type="text" id="fname" name="term" placeholder="Введите срок в месяцах.." value="<?php echo $term; ?>">
            </div>
        </div>
        <div class="row">
            <div class="col-25">
                <label for="country">Ставка</label>
            </div>
            <div class="col-75">
                <select id="country" name="rate">
                    <option value="14">14% от 30.000 до 99.999</option>
                    <option value="17">17% от 100.000 до 500.000</option>
                    <option value="19">19% от 500.000 до 1.000.000</option>
                </select>
            </div>
        </div>
        <div class="row">
            <div class="col-25">
                <label for="country">Периодичность капитализации %</label>
            </div>
            <div class="col-75">
                <select id="country" name="frequency">
                    <option value="once">В конце срока</option>
                    <option value="monthly">Ежемесячно</option>
                </select>
            </div>
        </div>
        <div class="row">
            <div class="col-25">
                <label for="fname">Cумма</label>
            </div>
            <div class="col-75">
                <input type="text" id="fname" name="amount" placeholder="Введите сумму вклада.." value="<?php echo $amount; ?>">
            </div>
        </div>
        <br>
        <div class="row">
            <input type="submit" name="deposit" class="button" value="Отправить заявку" />
        </div>
    </form>
    <div class="col">
        <?php if (isset($errors) && is_array($errors)): ?>
            <ul>
                <?php foreach ($errors as $error): ?>
                    <li> - <?php echo $error; ?></li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>

        <?php if (isset($_POST['credit']) || isset($_POST['deposit'])):?>
            <?php echo "<script type='text/javascript'>Ваша заявка успешно отправлена!</script>"; ?>
        <?php endif; ?>

    </div>

</div>
</body>
</html>