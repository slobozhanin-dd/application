-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Апр 04 2022 г., 17:12
-- Версия сервера: 8.0.24
-- Версия PHP: 8.0.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `application`
--

-- --------------------------------------------------------

--
-- Структура таблицы `credit`
--

CREATE TABLE `credit` (
  `id` int NOT NULL,
  `opendate` date NOT NULL,
  `term` int NOT NULL,
  `diffpay` int NOT NULL,
  `amount` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `credit`
--

INSERT INTO `credit` (`id`, `opendate`, `term`, `diffpay`, `amount`) VALUES
(29, '2022-04-04', 6, 1, 1000000);

-- --------------------------------------------------------

--
-- Структура таблицы `deposit`
--

CREATE TABLE `deposit` (
  `id` int NOT NULL,
  `opendate` date NOT NULL,
  `term` int NOT NULL,
  `rate` int NOT NULL,
  `frequency` varchar(255) NOT NULL,
  `amount` bigint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `deposit`
--

INSERT INTO `deposit` (`id`, `opendate`, `term`, `rate`, `frequency`, `amount`) VALUES
(22, '2022-04-04', 6, 14, 'once', 50000),
(28, '2022-04-04', 6, 14, 'monthly', 1000000);

-- --------------------------------------------------------

--
-- Структура таблицы `legalperson`
--

CREATE TABLE `legalperson` (
  `id` int NOT NULL,
  `surname` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `patronymic` varchar(255) NOT NULL,
  `inn` bigint NOT NULL,
  `agencyname` varchar(255) NOT NULL,
  `adress` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `ogrn` bigint NOT NULL,
  `agencyinn` bigint NOT NULL,
  `kpp` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `legalperson`
--

INSERT INTO `legalperson` (`id`, `surname`, `name`, `patronymic`, `inn`, `agencyname`, `adress`, `ogrn`, `agencyinn`, `kpp`) VALUES
(22, 'Слобожанин', 'Дмитрий', 'Дмитриевич', 123456789132, 'Быстробанк', 'г.Ижевск ул.Советская 33/2 оф.65', 1234567891234, 9876543212, 987654321),
(28, 'Слобожанин', 'Дмитрий', 'Дмитриевич', 123456789121, 'Быстробанк', 'г.Ижевск ул.Советская 33/2 оф.65', 1234567891234, 9876543212, 987654321);

-- --------------------------------------------------------

--
-- Структура таблицы `naturalperson`
--

CREATE TABLE `naturalperson` (
  `id` int NOT NULL,
  `surname` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `patronymic` varchar(255) NOT NULL,
  `inn` bigint NOT NULL,
  `birthdate` date NOT NULL,
  `passport` bigint NOT NULL,
  `dateissue` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `naturalperson`
--

INSERT INTO `naturalperson` (`id`, `surname`, `name`, `patronymic`, `inn`, `birthdate`, `passport`, `dateissue`) VALUES
(29, 'Слобожанин', 'Дмитрий', 'Дмитриевич', 123456789121, '1998-10-15', 1234123456, '1998-12-20');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `credit`
--
ALTER TABLE `credit`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `deposit`
--
ALTER TABLE `deposit`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `legalperson`
--
ALTER TABLE `legalperson`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `naturalperson`
--
ALTER TABLE `naturalperson`
  ADD PRIMARY KEY (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
