<?php

class FormController
{
    public function actionForm()
    {
        $surname = false;
        $name = false;
        $patronymic = false;
        $inn = false;
        $birthdate = false;
        $passport = false;
        $dateissue = false;
        $agencyname = false;
        $adress = false;
        $ogrn = false;
        $agencyinn = false;
        $kpp = false;


        if (isset($_POST['nextnatural'])) {

            $surname = $_POST['surname'];
            $name = $_POST['name'];
            $patronymic = $_POST['patronymic'];
            $inn = $_POST['inn'];
            $birthdate = $_POST['birthdate'];
            $passport = $_POST['passport'];
            $dateissue = $_POST['dateissue'];

            $errors = false;

            if (!User::checkName($surname)) {
                $errors[] = 'Введите фамилию';
            }
            if (!User::checkName($name)) {
                $errors[] = 'Введите имя';
            }
            if (!User::checkName($patronymic)) {
                $errors[] = 'Введите отчество';
            }
            if (!User::checkINN($inn)) {
                $errors[] = 'ИНН должен содержать 12 цифр';
            }
            if (!User::checkDate($birthdate)) {
                $errors[] = 'Дата рождения введена неверно';
            }
            if (!User::checkPassport($passport)) {
                $errors[] = 'Номер паспорта должен содержать 10 цифр';
            }
            if (!User::checkDate($dateissue)) {
                $errors[] = 'Дата выдачи введена неверно';
            }



            if ($errors == false) {


                $id_natural = User::checkNaturalId();
                $id_legal = User::checkLegalId();
                $id = User::checkMaxId($id_natural, $id_legal);
                $_SESSION['id'] = $id;

                User::registerNatural($id, $surname, $name, $patronymic, $inn, $birthdate, $passport, $dateissue);
                header("Location: /credit");
            }
        }

        if (isset($_POST['nextlegal'])) {

            $surname = $_POST['surname'];
            $name = $_POST['name'];
            $patronymic = $_POST['patronymic'];
            $inn = $_POST['inn'];
            $agencyname = $_POST['agencyname'];
            $adress = $_POST['adress'];
            $ogrn = $_POST['ogrn'];
            $agencyinn = $_POST['agencyinn'];
            $kpp = $_POST['kpp'];

            $errors = false;

            if (!User::checkName($surname)) {
                $errors[] = 'Введите фамилию';
            }
            if (!User::checkName($name)) {
                $errors[] = 'Введите имя';
            }
            if (!User::checkName($patronymic)) {
                $errors[] = 'Введите отчество';
            }
            if (!User::checkINN($inn)) {
                $errors[] = 'ИНН должен содержать 12 символов';
            }
            if (!User::checkName($agencyname)) {
                $errors[] = 'Введите название компании';
            }
            if (!User::checkAdress($adress)) {
                $errors[] = 'Введите адресс';
            }
            if (!User::checkOgrn($ogrn)) {
                $errors[] = 'ОГРН должен содержать 13 цифр';
            }
            if (!User::checkAgencyinn($agencyinn)) {
                $errors[] = 'ИНН компании должен содержать 10 цифр';
            }
            if (!User::checkKpp($kpp)) {
                $errors[] = 'КПП должен содержать 9 цифр';
            }

            if ($errors == false) {

                $id_natural = User::checkNaturalId();
                $id_legal = User::checkLegalId();
                $id = User::checkMaxId($id_natural, $id_legal);
                $_SESSION['id'] = $id;

                User::registerLegal($id, $surname, $name, $patronymic, $inn, $agencyname, $adress, $ogrn, $agencyinn, $kpp);
                header("Location: /credit");
            }

        }

        require_once(ROOT . '/views/form.php');
        return true;
    }
}
