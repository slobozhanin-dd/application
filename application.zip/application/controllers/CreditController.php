<?php

class CreditController
{
    public function actionCredit()
    {
        $opendate = false;
        $term = false;
        $rate = false;
        $frequency = false;
        $diffpay = false;
        $amount = false;

        if (isset($_POST['credit'])) {

            $opendate = $_POST['opendate'];
            $term = $_POST['term'];
            $diffpay = $_POST['diffpay'];
            $amount = $_POST['amount'];

            $errors = false;

            if (!Service::checkDate($opendate)) {
                $errors[] = 'Введите дату открытия кредита';
            }
            if (!Service::checkNull($term)) {
                $errors[] = 'Введите срок кредита';
            }
            if (!Service::checkNull($amount)) {
                $errors[] = 'Введите сумму кредита';
            }

            if ($errors == false) {

                $id = $_SESSION['id'];

                $result = Service::registerCredit($id, $opendate, $term, $diffpay, $amount);
                header("Location: /success");

            }
        }

        if (isset($_POST['deposit'])) {

            $opendate = $_POST['opendate'];
            $term = $_POST['term'];
            $rate = $_POST['rate'];
            $frequency = $_POST['frequency'];
            $amount = $_POST['amount'];

            $errors = false;

            if (!Service::checkDate($opendate)) {
                $errors[] = 'Неправильно введена дата открытия вклада';
            }
            if (!Service::checkNull($term)) {
                $errors[] = 'Введите срок вклада';
            }
            if (!Service::checkNull($amount)) {
                $errors[] = 'Введите сумму вклада';
            }

            if ($errors == false) {

                $id = $_SESSION['id'];

                Service::registerDeposit($id, $opendate, $term, $rate, $frequency, $amount);
                header("Location: /success");

            }

        }

        require_once(ROOT . '/views/credit.php');
        return true;
    }

    public function actionSuccess()
    {
        require_once(ROOT . '/views/success.php');
        return true;
    }

}
