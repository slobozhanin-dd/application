<?php

//Класс User - модель для работы с формой пользователя

class User
{

    public static function registerNatural($id, $surname, $name, $patronymic, $inn, $birthdate, $passport, $dateissue)
    {
        $db = Db::getConnection();

        $sql = 'INSERT INTO naturalperson (id, surname, name, patronymic, inn, birthdate, passport, dateissue) '
            . 'VALUES (:id, :surname, :name, :patronymic, :inn, :birthdate, :passport, :dateissue)';

        $result = $db->prepare($sql);
        $result->bindParam(':id', $id, PDO::PARAM_INT);
        $result->bindParam(':surname', $surname, PDO::PARAM_STR);
        $result->bindParam(':name', $name, PDO::PARAM_STR);
        $result->bindParam(':patronymic', $patronymic, PDO::PARAM_STR);
        $result->bindParam(':inn', $inn, PDO::PARAM_INT);
        $result->bindParam(':birthdate', $birthdate, PDO::PARAM_STR);
        $result->bindParam(':passport', $passport, PDO::PARAM_INT);
        $result->bindParam(':dateissue', $dateissue, PDO::PARAM_STR);
        return $result->execute();
    }

    public static function registerLegal($id, $surname, $name, $patronymic, $inn, $agencyname, $adress, $ogrn, $agencyinn, $kpp)
    {
        $db = Db::getConnection();

        $sql = 'INSERT INTO legalperson (id, surname, name, patronymic, inn, agencyname, adress, ogrn, agencyinn, kpp) '
            . 'VALUES (:id, :surname, :name, :patronymic, :inn, :agencyname, :adress, :ogrn, :agencyinn, :kpp)';

        $result = $db->prepare($sql);
        $result->bindParam(':id', $id, PDO::PARAM_INT);
        $result->bindParam(':surname', $surname, PDO::PARAM_STR);
        $result->bindParam(':name', $name, PDO::PARAM_STR);
        $result->bindParam(':patronymic', $patronymic, PDO::PARAM_STR);
        $result->bindParam(':inn', $inn, PDO::PARAM_INT);
        $result->bindParam(':agencyname', $agencyname, PDO::PARAM_STR);
        $result->bindParam(':adress', $adress, PDO::PARAM_STR);
        $result->bindParam(':ogrn', $ogrn, PDO::PARAM_INT);
        $result->bindParam(':agencyinn', $agencyinn, PDO::PARAM_INT);
        $result->bindParam(':kpp', $kpp, PDO::PARAM_INT);
        return $result->execute();

    }

    public static function checkNaturalId()
    {
        $db = Db::getConnection();

        $sql = 'SELECT MAX(id) FROM naturalperson';

        $result = $db->prepare($sql);
        $result->execute();
        $id_natural = $result->fetch();

        return $id_natural[0];
    }
    public static function checkLegalId()
    {
        $db = Db::getConnection();

        $sql = 'SELECT MAX(id) FROM legalperson';

        $result = $db->prepare($sql);
        $result->execute();
        $id_legal = $result->fetch();

        return $id_legal[0];
    }

    public static function checkMaxId($id_natural, $id_legal)
    {
        if($id_natural > $id_legal) {
            $id = $id_natural;
        }
        else $id = $id_legal;
        $id += 1;

        $_SESSION['id'] = $id;

        return $id;

    }


    public static function checkName($name)
    {
        if (strlen($name) > 0) {
            return true;
        }
        return false;
    }

    public static function checkAdress($adress)
    {
        if (strlen($adress) > 0) {
            return true;
        }
        return false;
    }

    public static function checkOgrn($ogrn)
    {
        if (strlen($ogrn) == 13) {
            return true;
        }
        return false;
    }

    public static function checkAgencyinn($agencyinn)
    {
        if (strlen($agencyinn) == 10) {
            return true;
        }
        return false;
    }

    public static function checkKpp($kpp)
    {
        if (strlen($kpp) == 9) {
            return true;
        }
        return false;
    }

    public static function checkInn($inn)
    {
        if (strlen($inn) == 12) {
            return true;
        }
        return false;
    }

    public static function checkDate($date)
    {
        $format = "Y-m-d";
        $Date = DateTime::createFromFormat($format, $date);
        if(!$Date) {
            return false;
        } else {
            return true;
        }

    }

    public static function checkPassport($passport)
    {
        if (strlen($passport) == 10) {
            return true;
        }
        return false;
    }

}

