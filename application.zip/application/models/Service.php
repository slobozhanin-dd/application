<?php

//Класс Service - модель для работы с формой услуги

class Service
{
    //Добавляем данные об услуге в базу

    public static function registerCredit($id, $opendate, $term, $diffpay, $amount)
    {
        $db = Db::getConnection();

        $sql = 'INSERT INTO credit (id, opendate, term, diffpay, amount) '
            . 'VALUES (:id, :opendate, :term, :diffpay, :amount)';

        $result = $db->prepare($sql);
        $result->bindParam(':id', $id, PDO::PARAM_INT);
        $result->bindParam(':opendate', $opendate, PDO::PARAM_STR);
        $result->bindParam(':term', $term, PDO::PARAM_INT);
        $result->bindParam(':diffpay', $diffpay, PDO::PARAM_INT);
        $result->bindParam(':amount', $amount, PDO::PARAM_INT);

        return $result->execute();
    }

    public static function registerDeposit($id, $opendate, $term, $rate, $frequency, $amount)
    {
        $db = Db::getConnection();

        $sql = 'INSERT INTO deposit (id, opendate, term, rate, frequency, amount) '
            . 'VALUES (:id, :opendate, :term, :rate, :frequency, :amount)';

        $result = $db->prepare($sql);
        $result->bindParam(':id', $id, PDO::PARAM_INT);
        $result->bindParam(':opendate', $opendate, PDO::PARAM_STR);
        $result->bindParam(':term', $term, PDO::PARAM_INT);
        $result->bindParam(':rate', $rate, PDO::PARAM_INT);
        $result->bindParam(':frequency', $frequency, PDO::PARAM_STR);
        $result->bindParam(':amount', $amount, PDO::PARAM_INT);

        return $result->execute();
    }

    public static function checkId()
    {
        $id_natural = User::checkNaturalId();
        $id_legal = User::checkLegalId();

        if($id_natural > $id_legal){
            $id = $id_natural;
        }
        else $id = $id_legal;
        return $id;
    }

    //Запоминаем пользователя

    public static function checkNull($number)
    {
        if (strlen($number) > 0) {
            return true;
        }
        return false;
    }

    public static function checkDate($date)
    {
        $format = "Y-m-d";
        $Date = DateTime::createFromFormat($format, $date);
        if(!$Date) {
            return false;
        } else {
            return true;
        }
    }

}

